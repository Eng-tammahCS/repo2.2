﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DataAccessLayer;

namespace calclator
{
    public partial class Form1 : Form
    {



        static int Precedentce(char op)
        {

            if (op == '+' || op == '-')
                return 1;
            else if (op == '*' || op == '/' || op == '%') return 2;
            else if (op == '^') return 3;
            else return 0;

        }

        static string Printstack(Stack<string> stack)
        {
            string ex = "";
            while (stack.Count() > 0)
                ex = stack.Pop().ToString() + ex;
            return ex;

        }
        static double CalclateArithemtic(double num1, double num2, char op)
        {
            if (op == '+')
                return num1 + num2;
            else if (op == '-')
                return num1 - num2;
            else if (op == '*')
                return num1 * num2;
            else if (op == '/')
                if (num2 == 0)
                {
                    MessageBox.Show("invalid divided on zero");
                    //throw new Exception("it is zero");
                    return num1 / num2;

                }
                else
                return num1 / num2;

                else if (op == '^')
                    return Math.Pow(num1, num2);

                else return 0;

        }
        static Stack<string> ConvertToPostfix(string exp)
        {
            Stack<string> output = new Stack<string>();
            Stack<char> stack = new Stack<char>();
            string number = "";
            foreach (char token in exp)
            {
                if (!char.IsWhiteSpace(token))
                    if (char.IsLetterOrDigit(token))
                        number += token.ToString();
                    else if (token == '(')

                        stack.Push(token);
                    else if (token == ')')
                    {
                        output.Push(number);
                        number = string.Empty;
                        while (stack.Count() > 0 && (stack.First() != '('))
                            output.Push(stack.Pop().ToString());
                        try
                        {
                            stack.Pop();
                        }
                        catch (Exception e)
                        {
                            //Console.WriteLine(e.ToString());
                            MessageBox.Show("the expression is not valid !");

                        }
                    }
                    else
                    {
                        output.Push(number);
                        number= string.Empty;

                        while (stack.Count() > 0 && (Precedentce(stack.First()) >= Precedentce(token)))
                            output.Push(stack.Pop().ToString());
                        stack.Push(token);
                    }
            }
            if (number != string.Empty)
            {
                output.Push(number);
                number = string.Empty;
            }
            while (stack.Count() > 0)
                if (output.First() == '('.ToString())
                {
                    //throw new Exception("the parenthese is not matching !");
                    MessageBox.Show(" the parenthese is not matching !");
                    break;
                }
                else
                    output.Push(stack.Pop().ToString());






            return ReserveStack(output);
        }
        static double Calclatepostfix(Stack<string> ex)
        {
            ex.Reverse<string>();
            Stack<double> oprands = new Stack<double>();
            string[] operators ="/,+,*,-,^,%".Split(',');
            double num1 = 0;
            double num2 = 0;
            string c;
            while (ex.Count()>0)
            {
                c=ex.Pop();
                if (c.All(char.IsDigit))
                    oprands.Push((int.Parse(c.ToString())));
                else if (Array.Exists(operators, op => op == c))
                {
                    num2 = Convert.ToDouble(oprands.Pop());
                    num1 = Convert.ToDouble(oprands.Pop());

                    oprands.Push(CalclateArithemtic(num1, num2, Convert.ToChar(c)));
                }
            }
            return oprands.Pop();

        }
        static Stack<string> ReserveStack(Stack<string> stack) {
            Stack<string> ret = new Stack<string>();
            foreach (string item in stack)
            {
                ret.Push(item);
            }

            return ret ;
        }
        static string ReplaceParenthece(string exp)
        {
            char[] chars = exp.ToCharArray();
            Array.Reverse(chars);
            //exp=new string(exp.Reverse().ToArray());

            for (int i = 0; i < chars.Length; i++)
            {
                if (chars[i] == '(')
                {
                    chars[i] = ')';
                }
                else if (chars[i] == ')')
                    chars[i] = '(';

            }
            return new string(chars);
        }
        static string ReverseExpression(string exp)
        {
            char[] chars = exp.ToCharArray();
            Array.Reverse(chars);
            return new string(chars);
        }
        static double CalclatePrefix(Stack<string> exp)
        {

            Stack<double> operands = new Stack<double>();
            Stack<string> operators = new Stack<string>();
            string[] ops = { "+", "-", "*", "/","%", "^" };


            foreach (string c in exp)
            {

                if (c.All(char.IsDigit))
                    operands.Push(double.Parse(c.ToString()));

                else if (Array.Exists(ops, item => item == c))
                {
                    operators.Push(c);
                }
            }
            double num1 = 0;
            double num2 = 0;
            char op;
            while (operators.Count > 0)
            {
                num2 = operands.Pop();
                num1 = operands.Pop();
                op =Convert.ToChar( operators.Pop());
                operands.Push(CalclateArithemtic(num1, num2, op));
            }



            return operands.Pop();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {


        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            label2.Text= Calclatepostfix(ConvertToPostfix(gtxt.Text.ToString())).ToString();
            //label1.Text = Printstack(ConvertToPostfix(gtxt.Text.ToString()));

            

        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
          
            Guna2CircleButton button =  (Guna2CircleButton)sender;

            string[] operators = "/,*,-,+,^,%".Split(',');

            if (gtxt.Text.Length == 0 && Array.Exists(operators,item=>item==button.Text.ToString())) {
                MessageBox.Show("must start with number or parentheces !");
            }
            else
            {
                gtxt.Text += button.Text.ToString();
            }
        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {

        }

        private void lblreasalt_Click(object sender, EventArgs e)
        {

        }

        private void gdelete_Click(object sender, EventArgs e)
        {
            gtxt.Text= null;
            lblreasalt.Text= "??";
        }

        private void geqqul_Click(object sender, EventArgs e)
        {
            lblreasalt.Text=Calclatepostfix(ConvertToPostfix(gtxt.Text)).ToString();
        }

        private void gredo_Click(object sender, EventArgs e)
        {
            gtxt.Text = gtxt.Text.Substring(0,gtxt.Text.Length-1);
            
        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
            Form frm = new frmRecord();
            frm.ShowDialog();
        }

        private void guna2Separator2_Click(object sender, EventArgs e)
        {

        }
    }
}
