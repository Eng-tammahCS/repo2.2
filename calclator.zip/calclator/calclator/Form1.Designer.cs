﻿namespace calclator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.gtxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gzero = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gdot = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g4 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g5 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g6 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g3 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g8 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g9 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton11 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.g7 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gdivide = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gadd = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gsub = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gmulti = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gclose = new Guna.UI2.WinForms.Guna2CircleButton();
            this.grem = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gexp = new Guna.UI2.WinForms.Guna2CircleButton();
            this.gopen = new Guna.UI2.WinForms.Guna2CircleButton();
            this.geqqul = new Guna.UI2.WinForms.Guna2Button();
            this.gredo = new Guna.UI2.WinForms.Guna2Button();
            this.gdelete = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.lblreasalt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ControlBox3 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2AnimateWindow1
            // 
            this.guna2AnimateWindow1.AnimationType = Guna.UI2.WinForms.Guna2AnimateWindow.AnimateWindowType.AW_SLIDE;
            this.guna2AnimateWindow1.TargetForm = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(176, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 0;
            // 
            // gtxt
            // 
            this.gtxt.AutoRoundedCorners = true;
            this.gtxt.BorderRadius = 38;
            this.gtxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gtxt.DefaultText = "";
            this.gtxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.gtxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.gtxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.gtxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.gtxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.gtxt.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.gtxt.ForeColor = System.Drawing.Color.Black;
            this.gtxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.gtxt.Location = new System.Drawing.Point(14, 95);
            this.gtxt.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.gtxt.Name = "gtxt";
            this.gtxt.PasswordChar = '\0';
            this.gtxt.PlaceholderText = "5*5";
            this.gtxt.SelectedText = "";
            this.gtxt.Size = new System.Drawing.Size(443, 78);
            this.gtxt.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(176, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 2;
            // 
            // gzero
            // 
            this.gzero.Animated = true;
            this.gzero.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gzero.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gzero.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gzero.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gzero.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gzero.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gzero.ForeColor = System.Drawing.Color.Black;
            this.gzero.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gzero.Location = new System.Drawing.Point(12, 634);
            this.gzero.Name = "gzero";
            this.gzero.ShadowDecoration.BorderRadius = 10;
            this.gzero.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gzero.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gzero.Size = new System.Drawing.Size(94, 76);
            this.gzero.TabIndex = 3;
            this.gzero.Tag = "0";
            this.gzero.Text = "0";
            this.gzero.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gdot
            // 
            this.gdot.Animated = true;
            this.gdot.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gdot.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gdot.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gdot.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gdot.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gdot.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gdot.ForeColor = System.Drawing.Color.Black;
            this.gdot.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gdot.Location = new System.Drawing.Point(344, 638);
            this.gdot.Name = "gdot";
            this.gdot.ShadowDecoration.BorderRadius = 10;
            this.gdot.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gdot.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gdot.Size = new System.Drawing.Size(94, 76);
            this.gdot.TabIndex = 7;
            this.gdot.Text = ".";
            this.gdot.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g2
            // 
            this.g2.Animated = true;
            this.g2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g2.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g2.ForeColor = System.Drawing.Color.Black;
            this.g2.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g2.Location = new System.Drawing.Point(231, 638);
            this.g2.Name = "g2";
            this.g2.ShadowDecoration.BorderRadius = 10;
            this.g2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g2.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g2.Size = new System.Drawing.Size(94, 76);
            this.g2.TabIndex = 8;
            this.g2.Tag = "2";
            this.g2.Text = "2";
            this.g2.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g1
            // 
            this.g1.Animated = true;
            this.g1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g1.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g1.ForeColor = System.Drawing.Color.Black;
            this.g1.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g1.Location = new System.Drawing.Point(120, 638);
            this.g1.Name = "g1";
            this.g1.ShadowDecoration.BorderRadius = 10;
            this.g1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g1.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g1.Size = new System.Drawing.Size(94, 76);
            this.g1.TabIndex = 9;
            this.g1.Tag = "1";
            this.g1.Text = "1";
            this.g1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g4
            // 
            this.g4.Animated = true;
            this.g4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g4.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g4.ForeColor = System.Drawing.Color.Black;
            this.g4.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g4.Location = new System.Drawing.Point(120, 552);
            this.g4.Name = "g4";
            this.g4.ShadowDecoration.BorderRadius = 10;
            this.g4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g4.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g4.Size = new System.Drawing.Size(94, 76);
            this.g4.TabIndex = 13;
            this.g4.Tag = "4";
            this.g4.Text = "4";
            this.g4.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g5
            // 
            this.g5.Animated = true;
            this.g5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g5.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g5.ForeColor = System.Drawing.Color.Black;
            this.g5.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g5.Location = new System.Drawing.Point(231, 552);
            this.g5.Name = "g5";
            this.g5.ShadowDecoration.BorderRadius = 10;
            this.g5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g5.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g5.Size = new System.Drawing.Size(94, 76);
            this.g5.TabIndex = 12;
            this.g5.Tag = "5";
            this.g5.Text = "5";
            this.g5.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g6
            // 
            this.g6.Animated = true;
            this.g6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g6.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g6.ForeColor = System.Drawing.Color.Black;
            this.g6.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g6.Location = new System.Drawing.Point(344, 552);
            this.g6.Name = "g6";
            this.g6.ShadowDecoration.BorderRadius = 10;
            this.g6.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g6.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g6.Size = new System.Drawing.Size(94, 76);
            this.g6.TabIndex = 11;
            this.g6.Tag = "6";
            this.g6.Text = "6";
            this.g6.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g3
            // 
            this.g3.Animated = true;
            this.g3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g3.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g3.ForeColor = System.Drawing.Color.Black;
            this.g3.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g3.Location = new System.Drawing.Point(12, 548);
            this.g3.Name = "g3";
            this.g3.ShadowDecoration.BorderRadius = 10;
            this.g3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g3.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g3.Size = new System.Drawing.Size(94, 76);
            this.g3.TabIndex = 10;
            this.g3.Tag = "3";
            this.g3.Text = "3";
            this.g3.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g8
            // 
            this.g8.Animated = true;
            this.g8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g8.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g8.ForeColor = System.Drawing.Color.Black;
            this.g8.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g8.Location = new System.Drawing.Point(120, 470);
            this.g8.Name = "g8";
            this.g8.ShadowDecoration.BorderRadius = 10;
            this.g8.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g8.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g8.Size = new System.Drawing.Size(94, 76);
            this.g8.TabIndex = 17;
            this.g8.Tag = "8";
            this.g8.Text = "8";
            this.g8.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // g9
            // 
            this.g9.Animated = true;
            this.g9.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g9.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g9.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g9.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g9.ForeColor = System.Drawing.Color.Black;
            this.g9.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g9.Location = new System.Drawing.Point(231, 470);
            this.g9.Name = "g9";
            this.g9.ShadowDecoration.BorderRadius = 10;
            this.g9.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g9.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g9.Size = new System.Drawing.Size(94, 76);
            this.g9.TabIndex = 16;
            this.g9.Tag = "9";
            this.g9.Text = "9";
            this.g9.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // guna2CircleButton11
            // 
            this.guna2CircleButton11.Animated = true;
            this.guna2CircleButton11.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton11.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.guna2CircleButton11.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.guna2CircleButton11.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton11.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton11.Location = new System.Drawing.Point(344, 470);
            this.guna2CircleButton11.Name = "guna2CircleButton11";
            this.guna2CircleButton11.ShadowDecoration.BorderRadius = 10;
            this.guna2CircleButton11.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton11.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.guna2CircleButton11.Size = new System.Drawing.Size(94, 76);
            this.guna2CircleButton11.TabIndex = 15;
            this.guna2CircleButton11.Text = "0";
            // 
            // g7
            // 
            this.g7.Animated = true;
            this.g7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.g7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.g7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.g7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.g7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.g7.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.g7.ForeColor = System.Drawing.Color.Black;
            this.g7.HoverState.BorderColor = System.Drawing.Color.Black;
            this.g7.Location = new System.Drawing.Point(12, 466);
            this.g7.Name = "g7";
            this.g7.ShadowDecoration.BorderRadius = 10;
            this.g7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.g7.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.g7.Size = new System.Drawing.Size(94, 76);
            this.g7.TabIndex = 14;
            this.g7.Tag = "7";
            this.g7.Text = "7";
            this.g7.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gdivide
            // 
            this.gdivide.Animated = true;
            this.gdivide.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gdivide.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gdivide.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gdivide.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gdivide.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gdivide.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gdivide.ForeColor = System.Drawing.Color.Black;
            this.gdivide.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gdivide.Location = new System.Drawing.Point(120, 386);
            this.gdivide.Name = "gdivide";
            this.gdivide.ShadowDecoration.BorderRadius = 10;
            this.gdivide.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gdivide.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gdivide.Size = new System.Drawing.Size(94, 76);
            this.gdivide.TabIndex = 21;
            this.gdivide.Text = "/";
            this.gdivide.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gadd
            // 
            this.gadd.Animated = true;
            this.gadd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gadd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gadd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gadd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gadd.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gadd.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gadd.ForeColor = System.Drawing.Color.Black;
            this.gadd.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gadd.Location = new System.Drawing.Point(231, 386);
            this.gadd.Name = "gadd";
            this.gadd.ShadowDecoration.BorderRadius = 10;
            this.gadd.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gadd.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gadd.Size = new System.Drawing.Size(94, 76);
            this.gadd.TabIndex = 20;
            this.gadd.Text = "+";
            this.gadd.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gsub
            // 
            this.gsub.Animated = true;
            this.gsub.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gsub.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gsub.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gsub.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gsub.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gsub.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gsub.ForeColor = System.Drawing.Color.Black;
            this.gsub.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gsub.Location = new System.Drawing.Point(344, 386);
            this.gsub.Name = "gsub";
            this.gsub.ShadowDecoration.BorderRadius = 10;
            this.gsub.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gsub.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gsub.Size = new System.Drawing.Size(94, 76);
            this.gsub.TabIndex = 19;
            this.gsub.Text = "-";
            this.gsub.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gmulti
            // 
            this.gmulti.Animated = true;
            this.gmulti.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gmulti.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gmulti.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gmulti.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gmulti.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gmulti.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gmulti.ForeColor = System.Drawing.Color.Black;
            this.gmulti.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gmulti.Location = new System.Drawing.Point(12, 382);
            this.gmulti.Name = "gmulti";
            this.gmulti.ShadowDecoration.BorderRadius = 10;
            this.gmulti.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gmulti.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gmulti.Size = new System.Drawing.Size(94, 76);
            this.gmulti.TabIndex = 18;
            this.gmulti.Text = "*";
            this.gmulti.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gclose
            // 
            this.gclose.Animated = true;
            this.gclose.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gclose.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gclose.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gclose.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gclose.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gclose.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gclose.ForeColor = System.Drawing.Color.Black;
            this.gclose.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gclose.Location = new System.Drawing.Point(120, 304);
            this.gclose.Name = "gclose";
            this.gclose.ShadowDecoration.BorderRadius = 10;
            this.gclose.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gclose.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gclose.Size = new System.Drawing.Size(94, 76);
            this.gclose.TabIndex = 25;
            this.gclose.Tag = ")";
            this.gclose.Text = ")";
            this.gclose.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // grem
            // 
            this.grem.Animated = true;
            this.grem.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.grem.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.grem.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.grem.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.grem.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.grem.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.grem.ForeColor = System.Drawing.Color.Black;
            this.grem.HoverState.BorderColor = System.Drawing.Color.Black;
            this.grem.Location = new System.Drawing.Point(231, 304);
            this.grem.Name = "grem";
            this.grem.ShadowDecoration.BorderRadius = 10;
            this.grem.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.grem.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.grem.Size = new System.Drawing.Size(94, 76);
            this.grem.TabIndex = 24;
            this.grem.Text = "%";
            this.grem.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gexp
            // 
            this.gexp.Animated = true;
            this.gexp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gexp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gexp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gexp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gexp.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gexp.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gexp.ForeColor = System.Drawing.Color.Black;
            this.gexp.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gexp.Location = new System.Drawing.Point(344, 304);
            this.gexp.Name = "gexp";
            this.gexp.ShadowDecoration.BorderRadius = 10;
            this.gexp.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gexp.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gexp.Size = new System.Drawing.Size(94, 76);
            this.gexp.TabIndex = 23;
            this.gexp.Text = "^";
            this.gexp.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // gopen
            // 
            this.gopen.Animated = true;
            this.gopen.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gopen.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gopen.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gopen.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gopen.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gopen.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gopen.ForeColor = System.Drawing.Color.Black;
            this.gopen.HoverState.BorderColor = System.Drawing.Color.Black;
            this.gopen.Location = new System.Drawing.Point(12, 300);
            this.gopen.Name = "gopen";
            this.gopen.ShadowDecoration.BorderRadius = 10;
            this.gopen.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gopen.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(10);
            this.gopen.Size = new System.Drawing.Size(94, 76);
            this.gopen.TabIndex = 22;
            this.gopen.Tag = "(";
            this.gopen.Text = "(";
            this.gopen.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // geqqul
            // 
            this.geqqul.AutoRoundedCorners = true;
            this.geqqul.BackColor = System.Drawing.Color.Transparent;
            this.geqqul.BorderRadius = 54;
            this.geqqul.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.geqqul.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.geqqul.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.geqqul.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.geqqul.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.geqqul.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold);
            this.geqqul.ForeColor = System.Drawing.Color.Black;
            this.geqqul.Location = new System.Drawing.Point(455, 423);
            this.geqqul.Name = "geqqul";
            this.geqqul.Size = new System.Drawing.Size(110, 274);
            this.geqqul.TabIndex = 1;
            this.geqqul.TabStop = false;
            this.geqqul.Text = "=";
            this.geqqul.Click += new System.EventHandler(this.geqqul_Click);
            // 
            // gredo
            // 
            this.gredo.AutoRoundedCorners = true;
            this.gredo.BackColor = System.Drawing.Color.Transparent;
            this.gredo.BorderRadius = 50;
            this.gredo.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gredo.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gredo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gredo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gredo.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gredo.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold);
            this.gredo.ForeColor = System.Drawing.Color.Black;
            this.gredo.Location = new System.Drawing.Point(452, 304);
            this.gredo.Name = "gredo";
            this.gredo.Size = new System.Drawing.Size(113, 102);
            this.gredo.TabIndex = 27;
            this.gredo.Text = "x";
            this.gredo.Click += new System.EventHandler(this.gredo_Click);
            // 
            // gdelete
            // 
            this.gdelete.AutoRoundedCorners = true;
            this.gdelete.BackColor = System.Drawing.Color.Transparent;
            this.gdelete.BorderRadius = 38;
            this.gdelete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gdelete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gdelete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gdelete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gdelete.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.gdelete.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.gdelete.ForeColor = System.Drawing.Color.Black;
            this.gdelete.Location = new System.Drawing.Point(465, 95);
            this.gdelete.Name = "gdelete";
            this.gdelete.Size = new System.Drawing.Size(111, 78);
            this.gdelete.TabIndex = 28;
            this.gdelete.Text = "حذف";
            this.gdelete.Click += new System.EventHandler(this.gdelete_Click);
            // 
            // guna2Separator1
            // 
            this.guna2Separator1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Separator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.guna2Separator1.FillThickness = 5;
            this.guna2Separator1.Location = new System.Drawing.Point(0, 279);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(576, 15);
            this.guna2Separator1.TabIndex = 30;
            // 
            // guna2Separator2
            // 
            this.guna2Separator2.BackColor = System.Drawing.Color.Transparent;
            this.guna2Separator2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(48)))), ((int)(((byte)(100)))));
            this.guna2Separator2.FillThickness = 5;
            this.guna2Separator2.Location = new System.Drawing.Point(0, 179);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(576, 15);
            this.guna2Separator2.TabIndex = 32;
            this.guna2Separator2.Click += new System.EventHandler(this.guna2Separator2_Click);
            // 
            // lblreasalt
            // 
            this.lblreasalt.AutoSize = true;
            this.lblreasalt.Font = new System.Drawing.Font("Tahoma", 25F, System.Drawing.FontStyle.Bold);
            this.lblreasalt.Location = new System.Drawing.Point(216, 212);
            this.lblreasalt.Name = "lblreasalt";
            this.lblreasalt.Size = new System.Drawing.Size(70, 51);
            this.lblreasalt.TabIndex = 33;
            this.lblreasalt.Text = "??";
            this.lblreasalt.Click += new System.EventHandler(this.lblreasalt_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 20F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(113, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(316, 41);
            this.label3.TabIndex = 35;
            this.label3.Text = "الحاسبة الاساسية";
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Image = global::calclator.Properties.Resources.menu__2_;
            this.guna2ImageButton1.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.Location = new System.Drawing.Point(12, 17);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Size = new System.Drawing.Size(77, 69);
            this.guna2ImageButton1.TabIndex = 34;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click);
            // 
            // guna2ControlBox3
            // 
            this.guna2ControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox3.BackgroundImage = global::calclator.Properties.Resources.delete__4_;
            this.guna2ControlBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox3.IconColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox3.Location = new System.Drawing.Point(435, 17);
            this.guna2ControlBox3.Name = "guna2ControlBox3";
            this.guna2ControlBox3.Size = new System.Drawing.Size(66, 51);
            this.guna2ControlBox3.TabIndex = 6;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.BackgroundImage = global::calclator.Properties.Resources.close__1_;
            this.guna2ControlBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.Location = new System.Drawing.Point(498, 17);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.Size = new System.Drawing.Size(67, 51);
            this.guna2ControlBox1.TabIndex = 4;
            this.guna2ControlBox1.Click += new System.EventHandler(this.guna2ControlBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(577, 725);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.guna2ImageButton1);
            this.Controls.Add(this.lblreasalt);
            this.Controls.Add(this.guna2Separator2);
            this.Controls.Add(this.guna2Separator1);
            this.Controls.Add(this.gdelete);
            this.Controls.Add(this.gredo);
            this.Controls.Add(this.geqqul);
            this.Controls.Add(this.gclose);
            this.Controls.Add(this.grem);
            this.Controls.Add(this.gexp);
            this.Controls.Add(this.gopen);
            this.Controls.Add(this.gdivide);
            this.Controls.Add(this.gadd);
            this.Controls.Add(this.gsub);
            this.Controls.Add(this.gmulti);
            this.Controls.Add(this.g8);
            this.Controls.Add(this.g9);
            this.Controls.Add(this.guna2CircleButton11);
            this.Controls.Add(this.g7);
            this.Controls.Add(this.g4);
            this.Controls.Add(this.g5);
            this.Controls.Add(this.g6);
            this.Controls.Add(this.g3);
            this.Controls.Add(this.g1);
            this.Controls.Add(this.g2);
            this.Controls.Add(this.gdot);
            this.Controls.Add(this.guna2ControlBox3);
            this.Controls.Add(this.guna2ControlBox1);
            this.Controls.Add(this.gzero);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gtxt);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox gtxt;
        private Guna.UI2.WinForms.Guna2CircleButton gzero;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox3;
        private Guna.UI2.WinForms.Guna2CircleButton g1;
        private Guna.UI2.WinForms.Guna2CircleButton g2;
        private Guna.UI2.WinForms.Guna2CircleButton gdot;
        private Guna.UI2.WinForms.Guna2CircleButton gclose;
        private Guna.UI2.WinForms.Guna2CircleButton grem;
        private Guna.UI2.WinForms.Guna2CircleButton gexp;
        private Guna.UI2.WinForms.Guna2CircleButton gopen;
        private Guna.UI2.WinForms.Guna2CircleButton gdivide;
        private Guna.UI2.WinForms.Guna2CircleButton gadd;
        private Guna.UI2.WinForms.Guna2CircleButton gsub;
        private Guna.UI2.WinForms.Guna2CircleButton gmulti;
        private Guna.UI2.WinForms.Guna2CircleButton g8;
        private Guna.UI2.WinForms.Guna2CircleButton g9;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton11;
        private Guna.UI2.WinForms.Guna2CircleButton g7;
        private Guna.UI2.WinForms.Guna2CircleButton g4;
        private Guna.UI2.WinForms.Guna2CircleButton g5;
        private Guna.UI2.WinForms.Guna2CircleButton g6;
        private Guna.UI2.WinForms.Guna2CircleButton g3;
        private Guna.UI2.WinForms.Guna2Button geqqul;
        private Guna.UI2.WinForms.Guna2Button gdelete;
        private Guna.UI2.WinForms.Guna2Button gredo;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private System.Windows.Forms.Label lblreasalt;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private System.Windows.Forms.Label label3;
    }
}

