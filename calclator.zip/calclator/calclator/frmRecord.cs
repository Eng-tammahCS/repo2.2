﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccessLayer;

namespace calclator
{
    public partial class frmRecord : Form
    {
        public frmRecord()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            LoadRecords();
        }

        void LoadRecords()
        {
            //DataTable dt = new DataTable();

            //dt = ;
            dataGridView1.DataSource = DataAccess.GetRecords();

//return ;
        }

        private void AllRecords_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
