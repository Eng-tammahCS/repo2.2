﻿//using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataAccessLayer
{



    public class DataAccess
    {

        static string connectionString()
        {
            string connectionString = "Server=.;Database=claclateDB;User ID=sa;Password=123456;";

            return connectionString;
        }

        public static DataTable GetRecords()
        {
            DataTable records = new DataTable();

            SqlConnection Connection = new SqlConnection(connectionString());

            string Query = "Select * from Records;";

            SqlCommand Command = new SqlCommand(Query, Connection);

            try
            {
                Connection.Open();
                SqlDataReader Reader = Command.ExecuteReader();

                records.Load(Reader);

                Reader.Close();
            }
            catch
            {
                //MessageBox.Show("the connection  with database is faild");

            }
            finally
            {
                Connection.Close();
            }
            return records;
        }
    }
}
