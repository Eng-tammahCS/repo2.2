<?php 
// session_start();
include 'include/header.php'; 
require_once 'include/conn.php';
?>
<?php
// session_start();
if (isset($_GET['index']) && isset($_SESSION['userinfo']['cart'][$_GET['index']])) {
    array_splice($_SESSION['userinfo']['cart'], $_GET['index'], 1);
}

?>


<div class="small-container cart-page">
    <table>
        <caption class="nameuser">Welcome <span style="color:#2a6194"><?php echo $_SESSION['userinfo']['username']; ?></span> Your Books</caption>
        <tr>
            <th>Product</th>
            <th>Subtotal</th>
        </tr>
        <?php
        $total = 0;
        if (isset($_SESSION['userinfo']['cart']) && !empty($_SESSION['userinfo']['cart'])) {
            foreach ($_SESSION['userinfo']['cart'] as $index => $product) {
                $total += $product['cost'];
                ?>
                <tr>
                    <td>
                        <div class='cart-info'>
                    
                        <img src='images/<?php echo $product["book_image1"]?>'>
                       
                            <div>
                                <p><?php echo$product['title']?></p>
                                <small>Price:$ <?php echo $product['cost']?></small>
                                <br>
                                <a href='?index=<?php echo $index?>'>Remove</a>
                            </div>
                        </div>
                    </td>
                    <td>$<?php echo $product['cost']?></td>
                </tr>
                <?php
            }
        } else {
            echo "<tr><td colspan='2'>Your cart is empty.</td></tr>";
        }
        ?>

    </table>
    <div class="total-price">
        <table>
            <tr>
                <td>Subtotal</td>
                <td>$<?php echo $total; ?></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <a class="btn" href="#">PAY</a>
                </td>
            </tr>
        </table>
    </div>
</div>

<?php include 'include/footer.php'; ?>
