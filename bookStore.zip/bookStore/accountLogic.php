
<?php
require_once 'include/conn.php';
        $Name = $Email = $Phone = $Address = $Password = '';

      $Errors=[];
        function test_input($data,$textError="",$for) {
            global $Errors;
            if(empty($data)){
                $Errors[$textError]='<h6 style="color:red;">*' ;
                $Errors[$textError].=$for.' is required </h6>' ;
              
            }
            else{

            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
            }
        }
        function checkDuplicate( $column, $Data) {
            global $conn;
            $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE $column = :x");
            

            // $stmt->bindParam(':x1', $column);
            $stmt->bindParam(':x', $Data);
            
            $stmt->execute();
            
            $count = $stmt->fetchColumn();
    // echo $count;
            return $count > 0; // Returns true if a duplicate is found
}





       
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $Name=test_input(    $_POST['name'],'NameErr' ,'name');
    $Email=test_input(   $_POST['email'] ,'EmailErr' ,'Email');
    $Phone=test_input(   $_POST['phone'] ,'PhoneErr' ,'Phone');
    $Password=test_input($_POST['password'] ,'PasswordErr','Password');
    $Address=test_input( $_POST['address'] ,'AddressErr','Address'); 

    if(isset($Name,$Email, $Phone, $Password)){
        
    
    

   // Additional validation for email format
    if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
        $Errors['EmailErr'] = '<h6 style="color:red;">* Invalid email format </h6>';
    }
    else if(checkDuplicate("email",$Email) && !isset($_SESSION['userinfo'])){
               $Errors['EmailErr'] = '<h6 style="color:red;">* this Enail is aleardy exists </h6>';
    }

    // Additional validation for phone number (10 digits)
    if (!preg_match("/^[0-9]{9}$/", $Phone)) {
        $Errors['PhoneErr'] = '<h6 style="color:red;">* Phone number must be 9 digits </h6>';
    } else if(checkDuplicate("phone",$Phone)&& !isset($_SESSION['userinfo'])){
               $Errors['PhoneErr'] = '<h6 style="color:red;">* Phone number is aleardy exists </h6>';
    }


    // Strict Password Validation (at least 6 characters, must include a number and a letter)    

    if (strlen($Password) < 6 &&!preg_match("/[A-Za-z]/", $Password) && !preg_match("/[0-9]/", $Password)) {
        $Errors['PasswordErr'] = '<h6 style="color:red;">* Password must be at least 6 characters long and include at least one letter and one number </h6>';
    }

   
} }
?>
    