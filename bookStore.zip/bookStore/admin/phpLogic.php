<?php
$Errors = array();
$Actions = array();
$row;
$Name = $Email = $Image = $Password = $Address = $Phone = $UserType = "";
function test_input($data, $textError = "", $for)
{
    global $Errors;
    if (empty($data)) {

        $Errors[$textError] = '<h6 style="color:red;">*';
        $Errors[$textError] .= $for . ' is required </h6>';

    } else {


        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        if ($for === 'Image') {
            test_image($data);
        }

        return $data;
    }
}



function test_image($image)
{
    global $Errors;

    $name = $_FILES["image"]["name"];
    $type_Extention = ["png", "jpg", "jpeg", "gif", "tif"];
    $ext = explode(".", $name);
    $ext = strtolower(end($ext));
    if (in_array($ext, $type_Extention)) {
        if ($_FILES["image"]["size"] < 2000000000) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], "../images/$name")) {

            } else {
                $err = '<h6 style="color:red;">*';
                $Errors["ImageErr"] = $err . 'image is fiald in load  </h6>';

            }
        } else {
            $err = '<h6 style="color:red;">*';
            $Errors["ImageErr"] = $err . 'image is large in size </h6>';
        }

    } else {
        $err = '<h6 style="color:red;">*';
        $Errors["ImageErr"] = $err . ' this file is  not allowed </h6>';
    }

}




function test_request()
{
    global $conn;
    global $Errors;
    global $row;
    global $Actions;
    global $Name, $Email, $Image, $Password, $Address, $Phone, $UserType;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $Name = test_input($_POST['name'], 'NameErr', 'name');
        $Email = test_input($_POST['email'], 'EmailErr', 'Email');
        $Image = test_input($_FILES['image']['name'], 'ImageErr', 'Image');
        $Phone = test_input($_POST['phone'], 'PhoneErr', 'Phone');
        $Password =password_hash( test_input($_POST['password'], 'PasswordErr', 'Password'),PASSWORD_DEFAULT);
        $Address = test_input($_POST['address'], 'AddressErr', 'Address');
        $UserType = test_input($_POST['usertype'], 'UserTypeErr', 'UserType');

        if ((empty($Errors))) {

            if (empty($_POST['user_id'])) {
                $Query = "INSERT INTO users (username, Email, Address, user_image, Pass, Phone, User_Type) 
                        VALUES (:username, :email, :address, :user_image, :pass, :phone, :user_type)";
                $statement = $conn->prepare($Query);
                $affectedif = $statement->execute([
                    ':username' => $Name,
                    ':email' => $Email,
                    ':address' => $Address,
                    ':user_image' => $Image,
                    ':pass' => $Password, // Hash password
                    ':phone' => $Phone,
                    ':user_type' => $UserType
                ]);
                if ($affectedif) {
                    $Actions['insert'] = "<h4 class='alert alert-success'> ✔ Inserted is done !</h4>";

                } else
                    $Actions['insert'] = "<h4 class='alert alert-danger'> ✖ Inserted is faild !</h4>";

            } else {
                $user_id = $_POST['user_id']; // Assuming user_id is passed in the server variables

                $Query = "UPDATE users 
                                    SET username = :username, 
                                        Email = :email, 
                                        Address = :address, 
                                        user_image = :user_image, 
                                        Pass = :pass, 
                                        Phone = :phone, 
                                        User_Type = :user_type 
                                    WHERE id = :user_id";

                $statement = $conn->prepare($Query);
                $affectedif = $statement->execute([
                    ':username' => $Name,
                    ':email' => $Email,
                    ':address' => $Address,
                    ':user_image' => $Image,
                    ':pass' => $Password, // Hash password
                    ':phone' => $Phone,
                    ':user_type' => $UserType,
                    ':user_id' => $user_id
                ]);

                if ($affectedif) {
                    $Actions['update'] = "<h4 class='alert alert-success'> ✔ Update is done!</h4>";
                } else {
                    $Actions['update'] = "<h4 class='alert alert-danger'> ✖ Update failed!</h4>";
                }
            }






        }
    }



    if (isset($_GET['action'], $_GET['user_id']) && intval($_GET['user_id'])) {
        switch ($_GET['action']) {
            case 'Delete':
                $Query = "delete from users where id=:x1;";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['user_id']]);
                if ($isSuccess) {
                    $Actions['delete'] = "<h4 class='alert alert-success'>the user is successfully deleted!</h4>";
                } else
                    $Actions['delete'] = "<h4 class='alert alert-danger'>the user is not deleted!</h4>";


                break;
            case 'Edit':
                $Query = "select * from   users  where id=:x1;";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['user_id']]);
                if ($isSuccess) {
                    $row = $prepareQuery->fetch();
                    $Actions['edit'] = "<h4 class='alert alert-success'>the user is successfully updated!</h4>";
                } else
                    $Actions['edit'] = "<h4 class='alert alert-danger'>the user is not updated!</h4>";




                break;
            case 'Block':
                $Query = "update  users set status='0' where id=:x1;";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['user_id']]);
                if ($isSuccess) {
                    $Actions['block'] = "<h4 class='alert alert-success'>the user is successfully blocked!</h4>";
                } else
                    $Actions['block'] = "<h4 class='alert alert-danger'>the user is not blocked!</h4>";



                break;
            case 'Unblock':
                $Query = "update  users set status='1' where id=:x1;";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['user_id']]);
                if ($isSuccess) {
                    $Actions['unblock'] = "<h4 class='alert alert-success'>the user is successfully unblocked!</h4>";
                } else
                    $Actions['unblock'] = "<h4 class='alert alert-danger'>the user is  blocked!</h4>";



                break;
            default:

        }


    }

}




?>