<?php
$Errors = array();
$Actions = array();
$row;
$BookName = $ISBN = $PublishDate = $Image = $Cost = $Category = $Details = "";

function test_input($data, $textError = "", $for)
{
    global $Errors;
    if (empty($data)) {
        $Errors[$textError] = '<h6 style="color:red;">*' . $for . ' is required </h6>';
    } else {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        if ($for === 'Image1') {
            test_image($data);
        }
        return $data;
    }
}

   function test_image($image){
            global $Errors;
            
            $name=$_FILES["image1"]["name"];
            $type_Extention=["png", "jpg", "jpeg", "gif", "tif","jfif"];
            $ext=explode(".",$name);
            $ext=strtolower(end($ext));
            if(in_array($ext,$type_Extention)){
                if($_FILES["image1"]["size"]>200){
                if(move_uploaded_file($_FILES["image1"]["tmp_name"],"../images/$name")){

                }
                else{
                    $err='<h6 style="color:red;">*';
                $Errors["ImageErr"]=$err.'image is fiald in load  </h6>' ;

                }}
                else{
                    $err='<h6 style="color:red;">*';
                    $Errors["ImageErr"]=$err.'image is large in size </h6>' ;
                }

            }
            else{
                $err='<h6 style="color:red;">*';
                $Errors["ImageErr"]=$err.' this file is  not allowed </h6>' ;
            }

        }

function test_request()
{
    global $conn, $Errors, $row, $Actions;
    global $BookName, $ISBN, $PublishDate, $Image, $Cost, $Category, $Details;
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $BookName = test_input($_POST['title'], 'BookNameErr', 'Book Name');
        $ISBN = test_input($_POST['isbn'], 'ISBNErr', 'ISBN');
        $PublishDate = test_input($_POST['publishdate'], 'PublishDateErr', 'Publish Date');
        $Image = test_input($_FILES['image1']['name'], 'ImageErr', 'Image');
        $Cost = test_input($_POST['cost'], 'CostErr', 'Cost');
        $Category = test_input($_POST['category'], 'CategoryErr', 'Category');
        $Details = test_input($_POST['details'], 'DetailsErr', 'Details');

        if (empty($Errors)) {
            if (empty($_POST['bookID'])) {
                $Query = "INSERT INTO books (title, ISBN, publishdate, book_image1, cost, category, details) 
                          VALUES (:title, :isbn, :publishdate, :book_image1, :cost, :category, :details)";
                $statement = $conn->prepare($Query);
                $affected = $statement->execute([
                    ':title' => $BookName,
                    ':isbn' => $ISBN,
                    ':publishdate' => $PublishDate,
                    ':book_image1' => $Image,
                    ':cost' => $Cost,
                    ':category' => $Category,
                    ':details' => $Details
                ]);
                if ($affected) {
                    $Actions['insert'] = "<h4 class='alert alert-success'>✔ Book inserted successfully!</h4>";
                } else {
                    $Actions['insert'] = "<h4 class='alert alert-danger'>✖ Book insertion failed!</h4>";
                }
            }
            else{

                
                            $bookID = $_POST['bookID']; // Assuming bookID is passed in the server variables

                             $Query = "UPDATE books 
                            SET title = :title, 
                                    ISBN = :isbn, 
                                    publishdate = :publishdate, 
                                    book_image1 = :book_image1, 
                                    cost = :cost, 
                                    category = :category, 
                                    details = :details 
                                WHERE id = :bookID"; // Update the record with the specified bookID

                                $statement = $conn->prepare($Query);
                                $affected = $statement->execute([
                                    ':title' => $BookName,
                                    ':isbn' => $ISBN,
                                    ':publishdate' => $PublishDate,
                                    ':book_image1' => $Image,
                                    ':cost' => $Cost,
                                    ':category' => $Category,
                                    ':details' => $Details,
                                    ':bookID' => $bookID // Include bookID in the parameters for the WHERE clause
                                ]);

                            if ($affected) {
                                $Actions['update'] = "<h4 class='alert alert-success'>✔ Book updated successfully!</h4>";
                            } else {
                                $Actions['update'] = "<h4 class='alert alert-danger'>✖ Book update failed!</h4>";
                            }
                        
            }
        }
    }

    if (isset($_GET['action'], $_GET['bookID']) && intval($_GET['bookID'])) {
        switch ($_GET['action']) {
            case 'Delete':
                $Query = "DELETE FROM books WHERE id = :x1";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['bookID']]);
                $Actions['delete'] = $isSuccess ? "<h4 class='alert alert-success'>Book deleted successfully!</h4>" : "<h4 class='alert alert-danger'>Book deletion failed!</h4>";
                break;
            case 'Edit':
                $Query = "SELECT * FROM books WHERE id = :x1";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['bookID']]);
                if ($isSuccess) {
                    $row = $prepareQuery->fetch();
                    $Actions['edit'] = "<h4 class='alert alert-success'>Book updated successfully!</h4>";
                } else {
                    $Actions['edit'] = "<h4 class='alert alert-danger'>Book update failed!</h4>";
                }
                break;
                case 'active':
                        $Query="update  books set status='1' where id=:x1;";
                        $prepareQuery=$conn->prepare($Query);
                        $isSuccess=$prepareQuery->execute(["x1"=>$_GET['bookID']]);
                        if($isSuccess){
                            $Actions['active']= "<h4 class='alert alert-success'>the book is successfully activated!</h4>";
                        }
                        else
                            $Actions['active']= "<h4 class='alert alert-danger'>the user book not actvated!</h4>";

                        

                    break;
                    case 'unactive':
                         $Query="update  books set status='0' where id=:x1;";
                        $prepareQuery=$conn->prepare($Query);
                        $isSuccess=$prepareQuery->execute(["x1"=>$_GET['bookID']]);
                        if($isSuccess){
                            $Actions['unactive']= "<h4 class='alert alert-success'>the book is successfully unactvated!</h4>";
                        }
                        else
                            $Actions['unactive']= "<h4 class='alert alert-danger'>the book is not  unactvated!</h4>";

                        

                    break;
                    
            default:

        }
    }
}
