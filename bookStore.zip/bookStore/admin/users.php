<?php require '../include/conn.php'; ?>
<?php include 'include/header.php'; ?>
<?php include 'include/sidebar.php'; ?>
<?php include 'phpLogic.php' ?>

<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2><i class="fa fa-users"></i> Users</h2>
            </div>
            <div class="col-md-12">
                 <?php
                            test_request();
                            ?>
                <?php
                                if (isset($Actions)) {

                        foreach ($Actions as $action)
                            echo $action;


                    }?>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-plus-circle"></i> Add New User
                         
                      
                    </div>
                    <div class="panel-body">
                        <div class="row">
                          
                            <div class="col-md-12">
                                <form role="form" action="users.php" enctype="multipart/form-data" method="POST">
                                    <div class="form-group">

                                        <input type="hidden" name="user_id"
                                            value="<?php if (isset($row['id'])) {
                                                echo ($row['id']);
                                            } ?>">
                                        <label>Name</label>
                                        <?php
                                        if (isset($Errors['NameErr']))
                                            echo $Errors['NameErr'];
                                        ?>
                                        <input type="text" placeholder="Please Enter your Name" class="form-control"
                                            name="name"
                                            value="<?php if (isset($row['username']))
                                                echo $row['username']; ?>">

                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <?php

                                        if (isset($Errors['EmailErr']))
                                            echo $Errors['EmailErr'];
                                        ?>
                                        <input type="email" placeholder="Please Enter your Email" class="form-control"
                                            name="email" value="<?php if (isset($row['email']))
                                                echo $row['email']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>User Image</label><br>
                                        <?php

                                        if (isset($Errors['ImageErr']))
                                            echo $Errors['ImageErr'];

                                        //    echo implode(      $Errors['ImageErr']); 
                                        ?>
                                        <img src="../images/<?php if (isset($row['user_image']))
                                            echo $row['user_image']; ?>"
                                            alt="User Image"
                                            style="border: none; width: 100px; border-radius: 50px; height: 100px; object-fit: fill;">
                                        <input type="file" class="form-control" name="image"
                                            value="<?php if (isset($row['user_image'])) {
                                                echo $row['user_image'];
                                            } ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>

                                        <?php

                                        if (isset($Errors['PasswordErr']))
                                            echo $Errors['PasswordErr'];
                                        ?>

                                        <input type="password" class="form-control" placeholder="Please Enter password"
                                            name="password" value="<?php if (isset($row['pass']))
                                                echo $row['pass']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" class="form-control" placeholder="Please Enter address"
                                            name="address"
                                            value="<?php if (isset($row['address']))
                                                echo $row['address']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Phone</label>

                                        <?php

                                        if (isset($Errors['PhoneErr']))
                                            echo $Errors['PhoneErr'];
                                        ?>

                                        <input type="tel" class="form-control" placeholder="Please Enter your phone"
                                            name="phone" value="<?php if (isset($row['phone']))
                                                echo $row['phone']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>User Type</label>
                                        <select class="form-control" name="usertype">
                                            <option value="1">Admin</option>
                                            <option value="2">User</option>
                                        </select>
                                    </div>

                                    <div style="float:right;">
                                        <?php
                                        if (isset($row['id'])) {
                                            ?>
                                            <button type="submit" class="btn btn-success">update User</button>
                                            <?php
                                        } else { ?>
                                            <button type="submit" class="btn btn-primary">Add User</button>
                                            <?php
                                        }
                                        ?>

                                        <button type="reset" class="btn btn-danger">Cancel</button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-users"></i> Users
                    </div>

                   

                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <?php
                                    global $conn;
                                    $select = $conn->prepare("SELECT * from users;");
                                    $select->execute();
                                    $rows = $select->fetchAll(PDO::FETCH_ASSOC);

                                    ?>

                                    <tr>
                                        <?php

                                        foreach ($rows[0] as $key => $value):
                                            echo "<th> $key</th>";
                                        endforeach;
                                        ?>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="odd gradeX">

                                        <?php
                                        foreach ($rows as $row) {
                                            echo '<tr class="odd gradeX" >';
                                            foreach ($row as $key => $value) {
                                                if ($key == 'user_image')
                                                    echo "<td><img src='../images/$value' alt='User Image' style='border: none; width: 100px; border-radius: 50px; height: 100px; object-fit: fill;'></td>";
                                                else if ($key == 'pass'){

                                        ?>

                                                   <td><?php echo substr($value, 0, 10);  ?></td>

                                           <?php } else
                                                    echo "<td>$value</td>";
                                            }
                                            ?>
                                            <td>
                                                <a href='?action=Edit&user_id=<?php echo $row['id'] ?>'
                                                    class='btn btn-success' name='Edit'>Edit</a>
                                                <a href='?action=Delete&user_id=<?php echo $row['id'] ?>'
                                                    class='btn btn-danger' name='Delete'>Delete</a>
                                                <?php
                                                if ($row['status'] === '1') {
                                                    ?>

                                                    <a href='?action=Block&user_id=<?php echo $row['id'] ?>'
                                                        class='btn btn-warning' name='Block'>Block</a>

                                                <?php } else {

                                                    ?>
                                                    <a href='?action=Unblock&user_id=<?php echo $row['id'] ?>'
                                                        class='btn btn-success' name='Unblock'>Unblock</a>
                                                <?php } ?>
                                            </td>

                                            <?php echo "</tr>";
                                        } ?>




                                    </tr>
                                    <!-- More rows can be added here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="assets/js/jquery-1.10.2.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.metisMenu.js"></script>
        <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
        <script src="assets/js/morris/morris.js"></script>
        <script src="assets/js/custom.js"></script>
    </div>
</div>
</div>
</body>

</html>