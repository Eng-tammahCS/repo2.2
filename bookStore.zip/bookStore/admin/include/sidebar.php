
<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu" >
                    <li>
                        <a href="index.php"><i class="fa fa-dashboard"></i> Control panel</a>
                    </li>
                    <li>
                        <a href="users.php"><i class="fa fa-users"></i> Users</a>
                    </li>
                    <li>
                        <a href="categories.php"><i class="fa fa-tasks"></i> Categories</a>
                    </li>
                    <li>
                        <a href="books.php"><i class="fa fa-bars"></i> Books</a>
                    </li>
                </ul>
            </div>
        </nav>