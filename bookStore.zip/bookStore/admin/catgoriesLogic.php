<?php
$Errors = array();
$Actions = array();
$row;
$CatName = $Image = "";

function test_input($data, $textError = "", $for)
{
    global $Errors;
    if (empty($data)) {
        $Errors[$textError] = '<h6 style="color:red;">*' . $for . ' is required </h6>';
    } else {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        if ($for === 'Image') {
            test_image($data);
        }
        return $data;
    }
}

function test_image($image)
{
    global $Errors;
    
    $name = $_FILES["image"]["name"];
    $type_Extension = ["png", "jpg", "jpeg", "gif", "tif"];
    $ext = explode(".", $name);
    $ext = strtolower(end($ext));
    
    if (in_array($ext, $type_Extension)) {
        if ($_FILES["image"]["size"] < 2000000) {  // Max 2MB
            if (move_uploaded_file($_FILES["image"]["tmp_name"], "../images/$name")) {
                return $name;
            } else {
                $Errors["ImageErr"] = '<h6 style="color:red;">* Image upload failed </h6>';
            }
        } else {
            $Errors["ImageErr"] = '<h6 style="color:red;">* Image is too large </h6>';
        }
    } else {
        $Errors["ImageErr"] = '<h6 style="color:red;">* Invalid file type </h6>';
    }
}

function test_request()
{
    global $conn, $Errors, $row, $Actions;
    global $CatName, $Image;

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $CatName = test_input($_POST['name'], 'CatNameErr', 'Category Name');
        $Image = test_input($_FILES['image']['name'], 'ImageErr', 'Image');

        if (empty($Errors)) {
            if (empty($_POST['category_id'])) {
                // Insert new category
                $Query = "INSERT INTO categories (catname, image) VALUES (:catname, :image)";
                $statement = $conn->prepare($Query);
                $affected = $statement->execute([
                    ':catname' => $CatName,
                    ':image' => $Image
                ]);
                if ($affected) {
                    $Actions['insert'] = "<h4 class='alert alert-success'>✔ Category inserted successfully!</h4>";
                } else {
                    $Actions['insert'] = "<h4 class='alert alert-danger'>✖ Category insertion failed!</h4>";
                }
            } else {
                // Update category
                $category_id = $_POST['category_id'];
                $Query = "UPDATE categories SET catname = :catname, image = :image WHERE id = :category_id";
                $statement = $conn->prepare($Query);
                $affected = $statement->execute([
                    ':catname' => $CatName,
                    ':image' => $Image,
                    ':category_id' => $category_id
                ]);
                if ($affected) {
                    $Actions['update'] = "<h4 class='alert alert-success'>✔ Category updated successfully!</h4>";
                } else {
                    $Actions['update'] = "<h4 class='alert alert-danger'>✖ Category update failed!</h4>";
                }
            }
        }
    }

    if (isset($_GET['action'], $_GET['category_id']) && intval($_GET['category_id'])) {
        switch ($_GET['action']) {
            case 'Delete':
                $Query = "DELETE FROM categories WHERE id = :x1";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['category_id']]);
                $Actions['delete'] = $isSuccess ? "<h4 class='alert alert-success'>Category deleted successfully!</h4>" : "<h4 class='alert alert-danger'>Category deletion failed!</h4>";
                break;
            case 'Edit':
                $Query = "SELECT * FROM categories WHERE id = :x1";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['category_id']]);
                if ($isSuccess) {
                    $row = $prepareQuery->fetch();
                    $Actions['edit'] = "<h4 class='alert alert-success'>Category updated successfully!</h4>";
                } else {
                    $Actions['edit'] = "<h4 class='alert alert-danger'>Category update failed!</h4>";
                }
                break;
            case 'active':
                $Query = "UPDATE categories SET status='1' WHERE id=:x1";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['category_id']]);
                $Actions['active'] = $isSuccess ? "<h4 class='alert alert-success'>Category activated successfully!</h4>" : "<h4 class='alert alert-danger'>Category activation failed!</h4>";
                break;
            case 'unactive':
                $Query = "UPDATE categories SET status='0' WHERE id=:x1";
                $prepareQuery = $conn->prepare($Query);
                $isSuccess = $prepareQuery->execute(["x1" => $_GET['category_id']]);
                $Actions['unactive'] = $isSuccess ? "<h4 class='alert alert-success'>Category deactivated successfully!</h4>" : "<h4 class='alert alert-danger'>Category deactivation failed!</h4>";
                break;
            default:
                // No action
        }
    }
}
?>
