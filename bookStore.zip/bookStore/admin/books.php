   
            <?php 
             require '../include/conn.php';
            include 'include/header.php'; 
               
            
            ?>
    
            <?php include 'include/sidebar.php';
                include 'BooksLogic.php';
            ?>

        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2><i class="fa fa-bars"></i> Book</h2>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="col-md-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-plus-circle"></i> Add New Book
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <?php test_request();?>
                                    <div class="col-md-12">
                                        <form role="form" action="Books.php" enctype="multipart/form-data" method="POST">

                                                
                                                <input type="hidden" name="bookID" value="<?php if(isset($row['id'])) echo $row['id'];?>">

                                        
                                            <div class="form-group">
                                                <label>Title</label>
                                                <?php 
                                                    if(isset($Errors['BookNameErr']))
                                                    echo  $Errors['BookNameErr'] ;
                                                ?>
                                                <input type="text" placeholder="Please Enter book's Name " class="form-control" name="title" value="<?php if(isset($row['title'])) echo $row['title'];?>">

                                            </div>
                                            <div class="form-group">
                                                <label>ISBN</label>
                                                <?php 
                                                    if(isset($Errors['ISBNErr']))
                                                    echo  $Errors['ISBNErr'] ;
                                                ?>  
                                                <input Type="text" placeholder="Please Enter  ISBN " class="form-control" name="isbn" value="<?php if(isset($row['isbn'])) echo $row['isbn'];?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Publish date</label>
                                                <?php 
                                                    if(isset($Errors['PublishDateErr']))
                                                    echo  $Errors['PublishDateErr'] ;
                                                ?>
                                                <input Type="date" placeholder="Please Enter  publish date " class="form-control" name="publishdate" value="<?php if(isset($row['publishdate'])) echo $row['publishdate'];?>" >
                                            </div>
                                            <div class="form-group">
                                                <label>Book image 1</label><br> 
                                                <?php 
                                                    if(isset($Errors['ImageErr']))
                                                    echo  $Errors['ImageErr'] ;
                                                ?>
                                                
                                             <img src="../images/<?php if(isset( $row['book_image1']))echo $row['book_image1'] ;?>" alt="User Image" style="border: none; width: 100px; border-radius: 50px; height: 100px; object-fit: fill;">
                                                <input type="file" class="form-control" name="image1" value="<?php if(isset($row['book_image1'])) {echo $row['book_image1'];}?>" >
                                                <label>Book image 2</label><br>
                                                <img src="../images/<?php if(isset( $row['book_image2']))echo $row['book_image2'] ;?>" alt="User Image" style="border: none; width: 100px; border-radius: 50px; height: 100px; object-fit: fill;">
                                                <input type="file" class="form-control" name="image2">
                                                <label>Book image 3</label><br>
                                                <img src="../images/<?php if(isset( $row['book_image3']))echo $row['book_image3'] ;?>" alt="User Image" style="border: none; width: 100px; border-radius: 50px; height: 100px; object-fit: fill;">
                                                <input type="file" class="form-control" name="image3">
                                                <!-- <label>Book image 4</label><br>
                                                <input type="file" class="form-control" name="image4"> -->
                                            </div>
                                            <div class="form-group">
                                                <label>Cost</label>
                                                <?php 
                                                    if(isset($Errors['CostErr']))
                                                    echo  $Errors['CostErr'] ;
                                                ?>
                                                <input type="text" class="form-control" placeholder="Please Enter the Cost" name="cost"value="<?php if(isset($row['cost'])) echo $row['cost'];?>" >
                                            </div>
                                            <div class="form-group">
                                                <label>Book Category</label>

                                                <?php 
                                                    if(isset($Errors['CategoryErr']))
                                                    echo  $Errors['CategoryErr'] ;
                                                ?>
                                                <select class="form-control" name="category" selected=<?php if(isset($row['category'])) echo $row['category'];?>>

                                                <?php 

                                                $stmt = $conn->prepare("SELECT id, CatName FROM categories");
                                                $stmt->execute();
                                                $categories = $stmt->fetchAll();
                                                $selectedCategory = isset($row['category']) ? $row['category'] : '';
                                                 foreach ($categories as $category) {
                                                    $selected = ($category['id'] == $selectedCategory) ? "selected" : "";
                                                    echo "<option value='{$category['id']}' $selected>{$category['CatName']}</option>";
                                                 }
 

                                                ?>
                                              
                                            </div>
                                           

                                              </select>

                                            <div class="form-group">
                                            <label>Another details</label>
                                                </br>
                                            <?php 
                                                    if(isset($Errors['DetailsErr']))
                                                    echo  $Errors['DetailsErr'] ;
                                                ?>
                                                <textarea name="details" rows="3" cols="72" value=""><?php if(isset($row['details'])) echo $row['details'];?></textarea>

                                            </div>
                                            <div style="float:right;">
                                                 <?php
                                                if(isset($row['id']))
                                                {
                                                ?>
                                                <button type="submit" class="btn btn-success">update Product</button>
                                                <?php
                                                }
                                                else
                                                {?>
                                                    <button type="submit" class="btn btn-primary">Add Product</button>
                                                <?php
                                                }
                                            ?>
                                                <button type="reset" class="btn btn-danger">Cancel</button>

                                                
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bars"></i> Product
                            </div>
                            <?php 
                             if(isset($Actions)){
                                
                                foreach($Actions as $action )
                                echo $action;
                              

                             }
                            ?>
                            
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                              <?php
                                                global $conn;
                                                $Query="SELECT * from books;";
                                                $select=$conn->prepare($Query);
                                                $select->execute();
                                                $rows = $select->fetchAll(PDO::FETCH_ASSOC);
                                                
                                                ?>
                                            <tr>
                                                <th>ID</th>
                                                <th>Book Name</th>
                                                <th>ISBN</th>
                                                <th>Publish date</th>
                                                <th>Image</th>
                                                <th>Cost</th>
                                                <th>Category</th>
                                                <th>Details</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                   
                                           <tbody>
                                    <tbody>
                                            <tr class="odd gradeX">
                                            
                                                <?php
                                                foreach ($rows as $row) {
                                                           

                                                    
                                                            ?>

                                                             <td><?php echo $row['id']; ?></td>
                                                            <td><?php echo $row['title']; ?></td>
                                                            <td><?php echo $row['isbn']; ?></td>
                                                            <td><?php echo $row['publishdate']; ?></td>
                                                            <td><img src="../images/<?php echo $row['book_image1']; ?>" alt="Book Image 1" style="width: 100px; height: 100px; object-fit: fill;"></td>
                                                            <td><?php echo $row['cost']; ?></td>
                                                            <td><?php echo $row['category']; ?></td>
                                                            <td><?php echo $row['details']; ?></td>
                                                         
                                                           
                                                            <td>
                                                                <a href='?action=Edit&bookID=<?php echo $row['id']; ?>' class='btn btn-success'>Edit</a>
                                                                <a href='?action=Delete&bookID=<?php echo $row['id']; ?>' class='btn btn-danger'>Delete</a>
                                                            
                                                    <?php
                                                    if ( $row['status']==='0' ){
                                                    ?>

                                                    <a href='?action=active&bookID=<?php echo $row['id'] ?>' class='btn btn-primary'name='active'>active</a>

                                                    <?php }
                                                    else{

                                                    ?>
                                                    <a href='?action=unactive&bookID=<?php echo $row['id'] ?>' class='btn btn-warning'name='unactive'>unactive</a>

                                                    <?php }?>
                                                    </td> 

                                                           <?php echo "</tr>";
                                                        }?>
                                                
                                                
                                                
                                               
                                            </tr>
                                            <!-- More rows can be added here -->
                                        </tbody>
                               


                                            <!-- More rows can be added here -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script src="assets/js/jquery-1.10.2.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script src="assets/js/jquery.metisMenu.js"></script>
                <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
                <script src="assets/js/morris/morris.js"></script>
                <script src="assets/js/custom.js"></script>
            </div>
        </div>
    </div>
</body>

</html>