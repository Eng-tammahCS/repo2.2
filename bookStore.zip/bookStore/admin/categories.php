<?php require '../include/conn.php';?>
<?php include 'include/header.php'; ?>
<?php include 'include/sidebar.php'; ?>
<?php include 'catgoriesLogic.php'?>

<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2><i class="fa fa-tasks"></i> Categories</h2>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-plus-circle"></i> Add New Category
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <?php test_request(); ?>
                            <div class="col-md-12">
                                <form role="form" action="categories.php" enctype="multipart/form-data" method="POST">
                                    <div class="form-group">
                                        <input type="hidden" name="category_id" value="<?php if(isset($row['id'])) echo $row['id']; ?>">
                                        <label>Name</label>
                                        <?php if(isset($Errors['NameErr'])) echo $Errors['NameErr']; ?>
                                        <input type="text" placeholder="Enter Category Name" class="form-control" name="name" value="<?php if(isset($row['catname'])) echo $row['catname']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Category Image</label><br>
                                        <?php if(isset($Errors['ImageErr'])) echo $Errors['ImageErr']; ?>
                                        <img src="../images/<?php if(isset($row['image'])) echo $row['image']; else echo 'default.jpg'; ?>" alt="Category Image" style="border: none; width: 100px; border-radius: 50px; height: 100px; object-fit: fill;">
                                        <input type="file" class="form-control" name="image">
                                    </div>
                                    <div style="float:right;">
                                        <?php if(isset($row['id'])) { ?>
                                            <button type="submit" class="btn btn-success">Update Category</button>
                                        <?php } else { ?>
                                            <button type="submit" class="btn btn-primary">Add Category</button>
                                        <?php } ?>
                                        <button type="reset" class="btn btn-danger">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-tasks"></i> Categories
                    </div>
                    <?php
                            if(isset($Actions)){
                                
                                foreach($Actions as $action )
                                echo $action;
                              

                             }
                            ?>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                    <tbody>
                                            <?php
                                            global $conn;
                                            $select = $conn->prepare("SELECT * FROM categories;");
                                            $select->execute();
                                            $rows = $select->fetchAll();

                                            foreach ($rows as $row) {
                                            ?>

                                            <tr class="odd gradeX">
                                                <td><?php echo $row['id']; ?></td>
                                                <td><?php echo $row['catname']; ?></td>
                                                <td><img src="../images/<?php echo $row['image']; ?>" alt="Book Image 1" style="width: 100px; height: 100px; object-fit: fill;"></td>

                                                <td>
                                                    <a href='?action=Edit&category_id=<?php echo $row['id']; ?>' class='btn btn-success'>Edit</a>
                                                    <a href='?action=Delete&category_id=<?php echo $row['id']; ?>' class='btn btn-danger'>Delete</a>

                                                    <?php
                                                    if ($row['status'] === '0') {
                                                    ?>
                                                        <a href='?action=active&category_id=<?php echo $row['id']; ?>' class='btn btn-primary' name='active'>Active</a>
                                                    <?php 
                                                    } else { 
                                                    ?>
                                                        <a href='?action=unactive&category_id=<?php echo $row['id']; ?>' class='btn btn-warning' name='unactive'>Inactive</a>
                                                    <?php 
                                                    } 
                                                    ?>
                                                </td>
                                            </tr>

                                            <?php 
                                            } 
                                            ?>

                                   

                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="assets/js/jquery-1.10.2.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.metisMenu.js"></script>
        <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
        <script src="assets/js/morris/morris.js"></script>
        <script src="assets/js/custom.js"></script>
    </div>
</div>
</body>
</html>
