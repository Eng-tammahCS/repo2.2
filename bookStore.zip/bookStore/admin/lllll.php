<?php
$username="HR";
$password="oracle";
$conn="";
$dsn="oci:dbname=//192.168.56.101:1521/freepdb1";

try{

$conn=new PDO($dsn,$username,$password);
$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
$conn->setattribute(PDO::ATTR_EMULATE_PREPARES,false);  

echo "connection is done";
//  "the connecting is done\n";

}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

?>