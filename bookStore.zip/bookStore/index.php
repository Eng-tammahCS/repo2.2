<?php include 'include/header.php'; 
require_once 'include/conn.php';

?>

            <div class="row header">
                <div class="col-2">
                    <h1>Find the Book That <br> Speaks to You</h1>
                    <p>
                        Success isn't always about greatness. It's about consistency. Consistent hard work gains success.
                        Greatness will come.
                    </p>
                    <a href="" class="btn">Explore Now &#8594;</a>
                </div>
                <div class="col-2">
                    <img src="images/open-book2.png" alt="" width="350" height="350">
                </div>
            </div>
        </div>
    </div>
    
    <!--------------------  featured categories --------------------->
    <div class="small-container">
        <div class="categories">
            <div class="row">
                <div class="col-3">
                    <img src="images/speaking.jpg">
                </div>
                <div class="col-3">
                    <img src="images/natrual.jpg">
                </div>
                <div class="col-3">
                    <img src="images/stars.jpg">
                </div>
            </div>
        </div>
    </div>
    
    <!--------------------  featured products --------------------->
    <?php

         $statement2 = $conn->prepare("SELECT * FROM books ");
                $statement2->execute();
                $rows = $statement2->fetchAll();


    ?>
    <div class="small-container">
        <h2 class="title">Featured Products</h2>
        <div class="row">
            <?php
            foreach($rows as $row){
            ?>
            <div class="col-4">
                <img src="images/<?php echo $row['book_image1']; ?>">
                <h4><?php echo $row['title']; ?></h4>
                <p>$<?php echo $row['cost']; ?></p>
                <!-- <button type="button" class="btn2"> view</button> -->
            </div>
            <?php }?>
           
        </div>
    </div>

    <!----------------------- offer ----------------------->
    <div class="offer">
        <div class="small-container">
            <div class="row">
                <div class="col-2">
                    <img src="images/png-transparent-jubilee-.png" class="offer-img">
                </div>
                <div class="col-2">
                    <p>
                        Exclusively Available on RedStore
                    </p>
                    <h1>Smart Band 4</h1>
                    <small>
                        The Mi Smart Band 4 features a 39.9% larger (than Mi Band 3) AMOLED color full-touch display
                        with adjustable brightness, so everything is clear as can be.
                    </small>
                    <a href="" class="btn">Buy Now &#8594;</a>
                </div>
            </div>
        </div>
    </div>

    <!------------------------- brands ---------------------------->
    <div class="brands">
        <div class="small-container">
            <div class="row">
                <div class="col-5">
                    <img src="images/logo-godrej.png">
                </div>
                <div class="col-5">
                    <img src="images/logo-oppo.png">
                </div>
                <div class="col-5">
                    <img src="images/logo-paypal.png">
                </div>
                <div class="col-5">
                    <img src="images/logo-philips.png">
                </div>
                <div class="col-5">
                    <img src="images/logo-coca-cola.png">
                </div>
            </div>
        </div>
    </div>

    <?php include 'include/footer.php'; ?>
