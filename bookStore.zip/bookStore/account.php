<?php
// session_start();
include 'include/header.php';
require_once 'include/conn.php';
require 'accountLogic.php';
?>

</div>
</div>
<!-------------------- account page ----------->
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' /* optional */
        });
    });
</script>

<div class="account-page">
    <div class="container">
        <div class="row">
            <div class="col-2">
                <!-- <img src="images/image1.png" width="100%"> -->
                <img src="images/open-book2.png" alt="" width="100%" height="500">

            </div>
            <div class="col-2">
                <div class="form-container" style="height: 550px; overflow:auto;">
                    <div class="form-btn">

                        <?php
                        if (isset($_SESSION['userinfo'])) {

                            echo "<span>Update Account</span>";
                        } else {
                            echo "<span>Create Account</span>";

                        }
                        ?>

                    </div>
                    <form action="account.php" method="POST">


                        <?php
                        if (isset($Errors['NameErr']))
                            echo $Errors['NameErr']; ?>
                        <input type="text" placeholder="Name" name="name"
                            value="<?php echo isset($_SESSION['userinfo']) ? $_SESSION['userinfo']['username'] : '' ?>">
                        <br>

                        <?php
                        if (isset($Errors['EmailErr']))
                            echo $Errors['EmailErr']; ?>

                        <input type="text" placeholder="Email" name="email"
                            value="<?php echo isset($_SESSION['userinfo']) ? $_SESSION['userinfo']['email'] : '' ?>">
                        <br>
                        <?php
                        if (isset($Errors['PhoneErr']))
                            echo $Errors['PhoneErr']; ?>
                        <input type="tel" placeholder="Phone" name="phone"
                            value="<?php echo isset($_SESSION['userinfo']) ? $_SESSION['userinfo']['phone'] : '' ?>">
                        <br>
                        <?php
                        if (isset($Errors['AddressErr']))
                            echo $Errors['AddressErr']; ?>

                        <input type="text" placeholder="Address" name="address"
                            value="<?php echo isset($_SESSION['userinfo']) ? $_SESSION['userinfo']['address'] : '' ?>">
                        <br>
                        <?php
                        if (isset($Errors['PasswordErr']))
                            echo $Errors['PasswordErr']; ?>
                        <input type="password" placeholder="Password" name="password"
                            value="<?php echo isset($_SESSION['userinfo']) ? $_SESSION['userinfo']['pass'] : '' ?>">
                        <br>




                        <?php
                        if (!isset($_SESSION['userinfo'])) {


                            ?>
                            <input type="submit" class="btn " style="background-color:#5e15b3" name="createaccount"
                                value="Create Account">
                            <a href="login.php" class="btn-danger" style="background-color:#2a6194"> log in</a>

                            <?php
                        } else {
                            ?>
                            <input type="submit" class="btn " style="background-color:#5e15b3" name="createaccount"
                                value="Update Account">
                            <?php

                        }
                        ?>
                        <br>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
if (isset($_POST['createaccount'])) {

    if (empty($Errors)) {
        if (!isset($_SESSION['userinfo'])) {
            $Password = password_hash($Password, PASSWORD_DEFAULT);
            $Query = "INSERT INTO `users`( `username`, `email`,
         `address`,  `pass`, `phone`) VALUES (:x1,:x2,:x3,:x4,:x5 );";
            $statement = $conn->prepare($Query);
            $statement->execute(["x1" => $Name, "x2" => $Email, "x3" => $Address, "x4" => $Password, "x5" => $Phone]);
            if ($statement->rowCount() == 1) {
                header("refresh:2 ;login.php");

                echo '<script type="text/javascript">
                        jQuery(function validation(){
                            swal("Login Success", "Welcome ' . "user" . '", "success", {
                                button: "Continue",
                            });
                        });
                        </script>';
            }

        } else {
            $Password = password_hash($Password, PASSWORD_DEFAULT);
            $Query = "UPDATE  `users` SET `username`=:x1, email=:x2,
         `address`=:x3,  `pass`=:x4, `phone`=:x5 
         where id=:x6";
            $statement = $conn->prepare($Query);
            // $statement->execute(["x1" => $Name, "x2" => $Email, "x3" => $Address, "x4" => $Password, "x5" => $Phone,"x6" => $_SESSION['userinfo']['id']]);
            if (
                $statement->execute([
                    ":x1" => $Name,
                    ":x2" => $Email,
                    ":x3" => $Address,
                    ":x4" => $Password,
                    ":x5" => $Phone,
                    ":x6" => $_SESSION['userinfo']['id']
                ])
            ) {
                $statement2 = $conn->prepare("SELECT * FROM USERS Where id=:x1");
                $statement2->execute(["x1" => $_SESSION['userinfo']['id']]);
                $newData = $statement2->fetch();
                $_SESSION['userinfo'] = $newData;

                echo '<script>
                
                alert("Your Account is successfuly updated");
                </script>';

            }
        }

    } else {
        echo '<script type="text/javascript">
                        jQuery(function validation(){
                            swal("Login Fail", "Username or Password is Wrong!", "error", {
                                button: "Continue",
                            });
                        });
                        </script>';


    }
}

?>
<!-------------------- Footer ----------------------->
<?php include 'include/footer.php'; ?>