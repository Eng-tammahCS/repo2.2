<?php
$servername="localhost";
$username="root";
$password="";
$dbname="BookStoreDB";
$conn="";
try{

$conn=new PDO("mysql:host=$servername;dbname=$dbname;",$username,$password);
$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
$conn->setattribute(PDO::ATTR_EMULATE_PREPARES,false);  

// $f='tammah';
// $v2=123;

//    $stmt = $conn->prepare("SELECT * FROM users");
    // $stmt->execute();

    // Fetch the row as an associative array
    // $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
// echo "the connecting is done\n";

}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

?>