<?php
require 'conn.php';
// try {
    // Create a PDO instance (connect to the database)
   
 
    $st=$conn->query("select * from users;");
    $rows=$st->fetchALL(PDO::FETCH_ASSOC);
$tableName="users";
        // Display the table data
        echo "<h2>Data from table: $tableName</h2>";
        echo "<table border='1'>";
        if (!empty($rows)) {
            // Display table headers
            echo '<pre>';
            // print_r($rows);
            echo'</pre>';
            echo "<tr>";
            foreach ($rows[0] as $key => $value) {
                echo "<th>$key</th>";
            }
            echo "</tr>";

            // Display table rows
            foreach ($rows as $row) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>$value</td>";
                }
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='100%'>No data found in the table.</td></tr>";
        }
        echo "</table>";
    // }

// catch (PDOException $e) {
//     // Handle connection or query errors
//     echo "Database error: " . $e->getMessage();
// }

// ?>



<?php
abstract class animal{
public $name;
public $sound;

function set_name($name){

    $this->name=$name;
    
} 
function set_sound($sound){

    $this->sound=$sound;

} 

}



$an=new animal();

$an->set_name("dog");
echo $an->name;

echo var_dump($an instanceof animal);


class Fruit {
  public $name;
  public $color;
  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color;
  }
  public function intro() {
    echo "The fruit is {$this->name} and the color is {$this->color}.";
  }
}

// Strawberry is inherited from Fruit
 class Strawberry extends Fruit {
  public function message() {
    echo "Am I a fruit or a berry? ";
  }
}
$strawberry = new Strawberry("Strawberry", "red");
$strawberry->message();
$strawberry->__construct("dddddddd", "red");
$strawberry->intro();
$strawberry->message();

echo '<br>';
echo var_dump($strawberry instanceof animal);



?>
<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Table Viewer</title>
</head>
<body>
    <h1>Enter Table Name to View Data</h1>
    <form method="POST" action="trying.php">
        <label for="table_name">Table Name:</label>
        <input type="text" id="table_name" name="table_name" required>
        <button type="submit">Show Data</button>
    </form>
</body>
</html>  -->
