<?php

    session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RedStore | Ecommerce Website Design</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="header">
        <div class="container">
            <div class="navbar" style="background-color:#5e15b3; border-radius:20px;">
                <div class="logo">
                    <a href="index.php"><img src="images/logo6.png" width="135px" height="40 px"></a>
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="index.php">Home</a></li>

                        <?php
                        if (isset($_SESSION['userinfo'])) { ?>


                            <li><a href="products.php">Products</a></li>


                            <?php
                        } ?>
                        <?php
                        if (isset($_SESSION['userinfo'])) { ?>


                            <li><a href="logout.php">log out</a></li>


                            <?php
                        } ?>
                        <?php
                        if (!isset($_SESSION['userinfo'])) { ?>


                            <li><a href="account.php">log In</a></li>



                            <?php
                        } ?>

                        <?php
                        if (isset($_SESSION['userinfo']) && $_SESSION['userinfo']['user_type'] == 'User') { ?>
                            <li><a href="account.php">Profile</a></li>


                        <?php
                        } ?>

                        <?php
                        if (isset($_SESSION['userinfo']) && $_SESSION['userinfo']['user_type'] == 'Admin') { ?>

                            <li><a href="admin/index.php">Control Panel</a></li>

                            <?php
                        } ?>



                        <!-- 
                        <li><a href="index.php">Home</a></li>
                        <li><a href="account.php">Login</a></li>
                        <li><a href="login.php">Log out</a></li>
                        <li><a href="profile.php">Profile</a></li>
                        <li><a href="account.php">Account</a></li> 
                        -->
                    </ul>
                </nav>
                <?php
                if (isset($_SESSION['userinfo'])) { ?>

                    <a href="cart.php"><img src="images/card2.png" width="30px" height="30px"></a>

                    <?php
                } ?>
                <!-- <a href="cart.php"><img src="images/card2.png" width="30px" height="30px"></a> -->
                <img src="images/menu.png" width="30px" height="30px" class="menu-icon" onclick="menutoggle()">
            </div>