#/bin/bash
echo tammah alabdi