<?php
Session_start();
$Errors = [];
$errmsg = "";
$messege = "";

function checkUser($Email, $pass)
{

    global $conn, $errmsg, $messege;
    // $select=$conn->prepare("SELECT * FROM users WHERE username=$user and password=$pass;");
// $select->execute(['username'=>$user,'pass'=>$passward]);
// $row=$select->fetch(PDO::FETCH_ASSOC);
// echo $user;
// echo "</hr>".$user;

    $stmt = $conn->prepare("SELECT * FROM users where email=:email ;");
    $stmt->execute(['email' => $Email]);
    // Fetch the row as an associative array
    $row = $stmt->fetch();


    if (!empty($row)) {
        if ($row['email'] == $Email && password_verify($pass, $row['pass']) && $row['user_type'] == 'Admin') {
            $_SESSION['userinfo'] = $row;
            $_SESSION['userinfo']['date'] = date('Y-m-d H:i:s');
            $messege = "success";
            header("refresh:2;admin/index.php");
        } else if ($row['email'] == $Email && password_verify($pass, $row['pass']) && $row['user_type'] == 'User') {
            $_SESSION['userinfo'] = $row;
            $_SESSION['userinfo']['date'] = date('Y-m-d H:i:s');
            $messege = "success";

            header("refresh:1;index.php");
        } else
            $errmsg = 'Invalid Email or Password ';

    }
    else
            $errmsg = 'Invalid Email or Password ';

    
}

function test_input($data = "", $textError = "", $for = "")
{
    global $Errors;
    if (empty($data)) {

        $Errors[$textError] = '<h6 style="color:red;">*';
        $Errors[$textError] .= $for . ' is required </h6>';

    } else {


        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);


        return $data;
    }
}




function test_request()
{
    $user = $password = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user = test_input($_POST['user'], 'userERR', 'username');
        $password = test_input($_POST['password'], 'passERR', 'password');
    }
}
?>