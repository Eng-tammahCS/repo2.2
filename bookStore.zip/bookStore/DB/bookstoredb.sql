-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2025 at 10:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstoredb`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `isbn` varchar(20) NOT NULL,
  `publishdate` date NOT NULL,
  `book_image1` varchar(300) DEFAULT NULL,
  `book_image2` varchar(300) DEFAULT NULL,
  `book_image3` varchar(300) DEFAULT NULL,
  `cost` decimal(10,2) NOT NULL,
  `category` enum('Science','Fiction','Non-Fiction','History','Biography') NOT NULL,
  `details` text DEFAULT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `isbn`, `publishdate`, `book_image1`, `book_image2`, `book_image3`, `cost`, `category`, `details`, `status`) VALUES
(3, 'ما وراء الطبيعة', 'A321548', '2025-01-01', 'natrual.jpg', NULL, NULL, 100.00, 'Science', 'كتاب يشرح الطبيعة بالتفصيل', '1'),
(5, 'الذكاء الاصطناعي', 'A321548el', '2025-01-03', 'Ai.jpg', NULL, NULL, 100.00, 'Science', 'افضل كتاب يشرح الذكاء الاصطناعي بالتفصيل', '1'),
(9, 'الادارة', 'A321548el0', '2025-01-03', 'images.jfif', NULL, NULL, 150.00, 'History', 'the best book in the world', '1'),
(10, 'النقد الادبي', 'A32154812', '2025-02-01', 'book28-12-2020-09-55-17.jpg', NULL, NULL, 50.00, 'History', 'افضل  كتاب في النقد الادبي', '1'),
(11, 'رحلة  النجوم', 'A321548A', '2025-02-06', 'stars.jpg', NULL, NULL, 100.00, 'Science', 'كتاب فخامة', '1'),
(13, 'الشغف', 'A321548el01', '2025-02-08', 'start-with.png', NULL, NULL, 50.00, 'History', 'يبدأ الامر بالشغف', '1'),
(14, 'التكنولوجيا ومستقبل الطاقة', 'A321548D', '2025-02-20', 'images (3).jfif', NULL, NULL, 150.00, 'Science', 'مستقبل التكنولوجيا والطاقة في العالم المتطور', '1'),
(15, 'تكنولوجيا المعلومات', 'A3215480', '2025-02-06', 'images (2).jfif', NULL, NULL, 35.50, 'Science', 'تكنولوجيا المعلومات والتطور العالمي', '1'),
(16, 'الوصايا الادبية', 'A3215488', '2025-02-06', 'images (5).jfif', NULL, NULL, 75.00, 'History', 'الوصايا العشر الذهبية', '1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `catname` varchar(500) NOT NULL,
  `image` varchar(500) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `catname`, `image`, `status`) VALUES
(1, 'Science', 'facebook.png', '0'),
(3, 'Medicine', NULL, '1'),
(4, 'Histort', NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(1000) NOT NULL,
  `user_image` varchar(300) DEFAULT NULL,
  `pass` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `user_type` enum('Admin','User') NOT NULL DEFAULT 'User',
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `address`, `user_image`, `pass`, `phone`, `user_type`, `status`) VALUES
(1, 'tammah', 'tammah@gmail.com', 'sana&#039;a', 'database (1).png', '123', '775410577', 'Admin', '1'),
(2, 'Ali', 'ali@gmial.com', 'sawan', 'office-man.png', '$2y$10$jvh9wAZtU6BANCXI7Z8SqO7onnfJPdLZxU7avHWrgSRbJQR7B4n3.', '770233485', 'User', '0'),
(27, 'Saif', 'saif@gmail.com', 'JADER', 'office-man.png', '$2y$10$wQIEsVK7CoPImNR4U0lNHeYp8TvO6jLVi1XQxuFQmMbWQTmorZnnO', '789512453', 'User', '0'),
(28, 'mohamed', 'mohamed@gmail.com', 'matar', 'full.jpg', '123', '789654221', 'User', '1'),
(29, 'asalah', 'asalah@gmil.com', 'hadah', 'full.jpg', '123', '789513215', 'User', '1'),
(31, 'Salah', 'salah@gmil.com', 'moaen', 'office-man.png', '$2y$10$BNWMk7ApH/b9oh2s7PVOiuig5EVvuuXTHqjg08.FXazz1d0kX45je', '7725695153', 'Admin', '1'),
(32, 'gggg', 'ggg@gmil.com', 'Jader', 'fulltjpg.jpg', '123', '778566312', 'User', '1'),
(40, 'taha', 'taha@gmail.com', 'hadah', 'photo_2025-01-25_05-43-41.jpg', '123', '7725695153', 'User', '1'),
(52, 'Azam', 'azam@gmail.com', 'hadah', 'office-man.png', '$2y$10$NMPWmdplGtBPO8YtJmoCiuDO3AbbRiNnrblZ77dDXYkQTg.8IttHG', '779952102', 'Admin', '1'),
(55, 'mohamed', 'mohamed1@gmail.com', 'matar', NULL, '$2y$10$g9tpdq/xC.kaLXDEc5AaMelXlWp.Z0OAZRuC9Io7lebbAURO8RscO', '779952101', 'User', '1'),
(56, 'Tam', 'tam@gmail.com', 'Raidah', NULL, '$2y$10$D4mOEecykrepe7vD6TRij.PW1SRJgSYeMLFpVWdeF00xxJtrfGdT6', '775510575', 'User', '1'),
(57, 'fatima', 'fatima@gamil.com', 'dddfff', '36333664.jpg', '$2y$10$9HHu4Qj5xBotXakpLCt9VeBttMFJO0vQF/uJIvAewdsMkf4a4DFr2', '123456789', 'Admin', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
