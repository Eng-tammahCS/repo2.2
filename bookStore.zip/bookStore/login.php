<?php
include 'include/conn.php';
// require_once 'include/header.php';
require 'checklogin.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="assets/css/font-awesome.css" rel="stylesheet" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style2.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/icheck/icheck.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/icheck/skins/square/blue.css">
  
    <script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' /* optional */
        });
    });
    </script>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Login</h2>
            <form action="login.php" method="post" >
                <div class="input-group">
                    <!-- <label for="username">Username</label> -->
                     <?php
                    //  test_request();

                    //  if(isset($Errors['userERR'])){
                    //     echo $Errors['userERR'];
                  
                  
                    // }else{
                    //  } 
                     ?>
                    <label for="Email" class="icon-label"><i class="fas fa-user" aria-hidden="true"></i> Email</label>

                    <input type="text" id="Email" name="email" >
                </div>
                <div class="input-group">
                    <!-- <label for="password">Password</label> -->
                    
                     <?php
                    // if(isset($Errors['passERR'])){
                    //     echo $Errors['passERR'];
                    //  }
                     ?> 

                    <label for="password" class="icon-label"><i class="fas fa-key" aria-hidden="true"></i> Password</label>
                    <input type="password" id="password" name="password" >

                </div>
                <?php
                // echo $_POST['user'];
                   if($_SERVER["REQUEST_METHOD"]=="POST"){
                  checkUser($_POST['email'],$_POST['password']);}
                
                                    
                    // $select=$conn->prepare("SELECT * FROM users WHERE username=$user and password=$pass;");
                    // $select->execute(['username'=>$user,'pass'=>$passward]);
                    // $row=$select->fetch(PDO::FETCH_ASSOC);
                    // echo $user;
                    // echo "</hr>".$user;
                
                
                ?>
                <?php
                    if(!empty($messege)){
                        echo '<script type="text/javascript">
                        jQuery(function validation(){
                            swal("Login Success", "Welcome '.$_SESSION['role'].'", "success", {
                                button: "Continue",
                            });
                        });
                        </script>';
                    } else {}

                    if(empty($errmsg)){
                        // No action taken if $errmsg is empty
                    } else {
                        echo '<script type="text/javascript">
                        jQuery(function validation(){
                            swal("Login Fail", "Username or Password is Wrong!", "error", {
                                button: "Continue",
                            });
                        });
                        </script>';
                    }
                    ?>







                <button type="submit" class="login-button">Login</button>
            </form>
            <div class="extra-links">
                <a href="#">Forgot Password?</a>
                <a href="account.php">Sign Up</a>
            </div>
        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js"></script>

</body>

</html>
