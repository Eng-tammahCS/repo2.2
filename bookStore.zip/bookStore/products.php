<?php require 'include/header.php'; 
require_once 'include/conn.php';

?>
</div>
</div>
    <!--------------------  featured products --------------------->
    <div class="small-container">
        <div class="row">

        <?php
        $Query="SELECT * FRom Books";
        $statement=$conn->prepare($Query);
        $statement->execute();
        $rows=$statement->fetchAll();

        foreach($rows as $oneRow){
        ?>

            <div class="col-4">
                <a href="productsdetails.php?id=<?php echo $oneRow['id'];?>"><img src="images/<?php echo  $oneRow['book_image1']?>"></a>
                <h4><?php echo $oneRow['title']?></h4>
                <p><?php echo $oneRow['cost']?></p>
            </div>
            <?php }?>


           
            
           
   

        </div>
    </div>

    <?php include 'include/footer.php'; ?>
