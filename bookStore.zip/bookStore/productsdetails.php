<?php include 'include/header.php'; 

require_once 'include/conn.php';
?>
</div>
</div>
    <!--------------------  single product details ---------------->
    <?php
            if(isset($_GET['id']) && intval($_GET['id'])){
                $Query="SELECT * FROM Books where ID=:ID ";
                $statement=$conn->prepare($Query);
                $statement->execute(["ID"=>$_GET['id']]);
                if($statement->rowCount()==1){
                    $oneRow=$statement->fetch();
                }


            }

    ?>
    <div class="small-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="images/<?php echo $oneRow['book_image1']?? '.jpg';?>" width="100%" id="productImg">
                <div class="small-img-row">
                    <div class="small-img-col">
                        <img src="images/<?php echo $oneRow['book_image1']?? '.jpg';?>" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/<?php echo $oneRow['book_image2']?? '.jpg';?>" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/<?php echo $oneRow['book_image3']?? '.jpg';?>" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/<?php echo $oneRow['book_image14']?? '.jpg';?>" width="100%" class="small-img">
                    </div>
                </div>
            </div>

            <div class="col-2">
                <h2>Title:</h2>
                <h3><pre>    <?php  echo $oneRow['title']?></pre></h3>
                <h2>details:</h2>
                <h3><pre>     <?php  echo $oneRow['details']?> </pre> </h3>
                <h2>cost:</h2>
                <h3><pre>     <?php  echo $oneRow['cost']?></pre></h3>

                
                <a class="btn" href="cart.php?ID=<?php echo $_GET['id']?>">Add To Cart</a>
            </div>

        </div>
    </div>
   <?php
// session_start();

if (!isset($_SESSION['userinfo']['cart'])) {
    $_SESSION['userinfo']['cart'] = []; // Initialize cart if not set
}

   $isfound = false;
   foreach(   $_SESSION['userinfo']['cart'] as $row){
    if($row['id']==$_GET['id']){
           $isfound = true;
    }
   }

if ($_SERVER["REQUEST_METHOD"] == "GET") {
       if (!$isfound) {
           $product = $oneRow;
           $_SESSION['userinfo']['cart'][] = $product;
       } // Add product to the user session
}

// header("Location: cart.php"); // Redirect to cart page
// exit();
?>

    <!-------------------- title ------------------------>
        <div class="small-container">
            <div class="row row-2">
                <h2>Related Products</h2>
                <p>View More</p>
            </div>
        </div>
<?php
            if(isset($_GET['id']) && intval($_GET['id'])){
                $Query="SELECT * FROM Books where category=:x1 ";
                $statement=$conn->prepare($Query);
                $statement->execute(["x1"=>$oneRow['category']]);
                if($statement->rowCount()>=1){
                    $RelatedRows=$statement->fetchAll();
                }


            }
?>
    <!-------------------- products --------------------->
    
    <div class="small-container">
        <div class="row">
            <?php 
        foreach($RelatedRows as $oneRow){?>

            <div class="col-4">

            <a href="productsdetails.php?id=<?php echo $oneRow['id']?> "> <img src="images/<?php echo $oneRow['book_image1'];?>"></a>
                
           
              <h4><?php echo $oneRow['title']?></h4>
                <p><?php echo $oneRow['cost']?></p>
    
            </div>
            <?php }?>

            
      
        </div>
    </div>

    <?php include 'include/footer.php'; ?>

